// priority: 990
const RegistryOrgan = serverField.core.funcs.RegistryOrgan
const RegistryOrganStrategy = serverField.core.funcs.RegistryOrganStrategy
const OrganStrategyModel = serverField.core.funcs.OrganStrategyModel